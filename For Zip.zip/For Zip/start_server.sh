#!/bin/bash

# Change to application directory
cd application

# Activate conda environment
source activate adk-new-env

# Start the Python server in a new background process
python -m server &
SERVER_PID=$!

# Go back to the root directory
cd ..

# Activate conda environment again (if needed)
source activate adk-new-env

# Start Python HTTP server in background
python -m http.server 8090 &
HTTP_PID=$!

# Start ADK web server in background
adk web --no-reload --host 0.0.0.0 &
ADK_PID=$!

# Wait for 5 seconds
sleep 5

# Open the browser
open "http://127.0.0.1:8000/dev-ui?app=application"

# Handle cleanup on exit
trap "kill $SERVER_PID $HTTP_PID $ADK_PID" EXIT
wait 