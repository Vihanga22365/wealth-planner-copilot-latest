import os
import sqlite3
import numpy as np
import socket
# Conceptual Code: Hierarchical Research Task
from google.adk.agents import LlmAgent
from google.adk.tools import agent_tool
from dotenv import load_dotenv
from typing import List, Dict, Any
# from google.adk.tools.mcp_tool import MCPToolset, StdioServerParameters
# from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters

load_dotenv()

os.environ["GOOGLE_API_KEY"] = os.getenv('GOOGLE_API_KEY')
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
# os.environ["LANGSMITH_TRACING"]='true'
# os.environ["LANGSMITH_ENDPOINT"]="https://api.smith.langchain.com"
# os.environ["LANGSMITH_API_KEY"]=os.getenv("LANGSMITH_API_KEY")
# os.environ["LANGSMITH_PROJECT"]="Research Agent - Saleforce"


# from langfuse import Langfuse

# langfuse = Langfuse(
#   secret_key="sk-lf-3bd352b3-ad5e-4134-a28e-c38cf4049a04",
#   public_key="pk-lf-6478fce6-c8e4-46ce-8be8-8de0aa865137",
#   host="https://cloud.langfuse.com"
# )


import base64
 
# Get keys for your project from the project settings page: https://cloud.langfuse.com
os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-lf-6478fce6-c8e4-46ce-8be8-8de0aa865137" 
os.environ["LANGFUSE_SECRET_KEY"] = "sk-lf-3bd352b3-ad5e-4134-a28e-c38cf4049a04" 
os.environ["LANGFUSE_HOST"] = "https://cloud.langfuse.com" # 🇪🇺 EU region
# os.environ["LANGFUSE_HOST"] = "https://us.cloud.langfuse.com" # 🇺🇸 US region
 
# Build Basic Auth header.
LANGFUSE_AUTH = base64.b64encode(
    f"{os.environ.get('LANGFUSE_PUBLIC_KEY')}:{os.environ.get('LANGFUSE_SECRET_KEY')}".encode()
).decode()
 
# Configure OpenTelemetry endpoint & headers
os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = os.environ.get("LANGFUSE_HOST") + "/api/public/otel"
os.environ["OTEL_EXPORTER_OTLP_HEADERS"] = f"Authorization=Basic {LANGFUSE_AUTH}"


from langfuse import get_client
 
langfuse = get_client()
 
# Verify connection
if langfuse.auth_check():
    print("Langfuse client is authenticated and ready!")
else:
    print("Authentication failed. Please check your credentials and host.")

import requests
from langchain_openai import OpenAIEmbeddings
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_community.vectorstores import FAISS
from google.adk.models.lite_llm import LiteLlm




import logging

from typing import Any
from uuid import uuid4

import httpx

from a2a.client import A2ACardResolver, A2AClient
from a2a.types import (
    AgentCard,
    MessageSendParams,
    SendMessageRequest,
    SendStreamingMessageRequest,
)


llm = ChatOpenAI(model="gpt-4.1", temperature=0.0)
embeddings = OpenAIEmbeddings(model="text-embedding-3-large")

def get_localhost_ip():
    """
    Get the localhost IP address that works reliably across different operating systems.
    
    Returns:
        str: The localhost IP address (e.g., "127.0.0.1")
    """
    try:
        # Method 1: Try to get the local IP by connecting to a known address
        # This is more reliable than hostname resolution
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # Connect to a public DNS server (doesn't actually send data)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            
            # If we got a valid IP that's not localhost, use it
            if local_ip and local_ip != "127.0.0.1":
                return local_ip
            else:
                # Fallback to localhost
                return "127.0.0.1"
                
    except Exception as e:
        print(f"Error getting localhost IP: {e}")
        # Fallback to localhost
        return "127.0.0.1"

def format_docs(docs):
  format_D="\n\n".join([d.page_content for d in docs])
  return format_D


def rag_inquiry_handler_tool(question: str) -> str:
    """
      Ask a question using the RAG.
      User can ask a question about our company and get the answer from the RAG.
    
      Args:
          question (str): The question to ask
          
      Returns:
          str: The answer to the question
        
           
    """
    # Fix the path to point to the correct faiss_db directory
    faiss_db_path = os.path.join(os.path.dirname(__file__), "faiss_db")
    docsearch = FAISS.load_local(faiss_db_path, embeddings, allow_dangerous_deserialization=True)
    retriever = docsearch.as_retriever(search_kwargs={"k": 5})
    
    template = """
            You are report generator.
            In the 'Question' section include the question.
            In the 'Context' section include the nessary context to generate the section of the report.
            According to the 'Context', please generate the section of the report.
            Use only the below given 'Context' to generate the section of the report.
            Make sure to provide the answer from the 'Context' only.
            Provide answer only. Nothing else.
            Context: {context}
            Question : {question}
            """
              
    prompt=ChatPromptTemplate.from_template(template)
    
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    response = rag_chain.invoke(question)
    return response

def code_interpreter_tool(code: str) -> str:
    """
    Executes the provided Python code and returns the output.
    """
    # Define a restricted execution environment
    restricted_globals = {"__builtins__": {}}
    restricted_locals = {}

    try:
        # Execute the code within the restricted environment
        exec(code, restricted_globals, restricted_locals)
        return str(restricted_locals)
    except Exception as e:
        return f"Error: {e}"
    
# def get_user_interactions_A2A_server(user_identifier: str) -> List[Dict[str, Any]]:
async def get_user_interactions_A2A_server(message: str) -> str:
    """
    Invoke the Customer Information Agent with a message and return the response.
    
    Args:
        message (str): The message to send to the agent.
        
    Returns:
        str: The response from the agent.
    """
    if not message or not isinstance(message, str):
        return "Error: Invalid message parameter. Please provide a valid string message."

    PUBLIC_AGENT_CARD_PATH = '/.well-known/agent.json'
    base_url = 'http://127.0.0.1:9999'
    max_retries = 1
    timeout = httpx.Timeout(30.0, connect=10.0)  # 30 seconds total timeout, 10 seconds connect timeout

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    for attempt in range(max_retries):
        try:
            async with httpx.AsyncClient(timeout=timeout) as httpx_client:
                # Initialize A2ACardResolver
                resolver = A2ACardResolver(
                    httpx_client=httpx_client,
                    base_url=base_url,
                )

                final_agent_card_to_use: AgentCard | None = None

                try:
                    _public_card = await resolver.get_agent_card()
                    final_agent_card_to_use = _public_card

                except Exception as e:
                    logger.error(
                        f'Critical error fetching public agent card (Attempt {attempt + 1}/{max_retries}): {e}', exc_info=True
                    )
                    if attempt == max_retries - 1:
                        return f"Error: Failed to fetch the public agent card after {max_retries} attempts. {str(e)}"
                    continue

                client = A2AClient(
                    httpx_client=httpx_client, agent_card=final_agent_card_to_use
                )
                logger.info('A2AClient initialized.')

                # Create message payload with proper structure
                message_id = uuid4().hex
                send_message_payload = {
                    'message': {
                        'role': 'user',
                        'parts': [{'kind': 'text', 'text': message}],
                        'messageId': message_id
                    }
                }

                # Create request with proper structure
                request = SendMessageRequest(
                    id=message_id,
                    params=MessageSendParams(**send_message_payload)
                )

                try:
                    response = await client.send_message(request)
                    final_res = response.model_dump(mode='json', exclude_none=True)
                    
                    # Log the full response for debugging
                    logger.info(f"Received response: {final_res}")
                    
                    return final_res

                except httpx.ReadTimeout as e:
                    logger.error(f"Timeout error sending message (Attempt {attempt + 1}/{max_retries}): {str(e)}", exc_info=True)
                    if attempt == max_retries - 1:
                        return f"Error: Request timed out after {max_retries} attempts. Please try again later."
                    continue
                except Exception as e:
                    logger.error(f"Error sending message (Attempt {attempt + 1}/{max_retries}): {str(e)}", exc_info=True)
                    if attempt == max_retries - 1:
                        return f"Error sending message after {max_retries} attempts: {str(e)}"
                    continue

        except Exception as e:
            logger.error(f"Error in customer_info_agent (Attempt {attempt + 1}/{max_retries}): {str(e)}", exc_info=True)
            if attempt == max_retries - 1:
                return f"Error: {str(e)}"
            continue

    return "Error: All retry attempts failed"

def get_user_transactions(user_identifier: str) -> List[Dict[str, Any]]:
    """
    Retrieve all transactions for a specific user by ID or partial name.
    
    Args:
        user_identifier (str): The ID or partial name of the user to retrieve transactions for
        
    Returns:
        List[Dict[str, Any]]: List of dictionaries containing transaction data
        Each dictionary contains: ID, UserID, Type, Amount, Date, Counterparty, 
        AccountNumber, and Description
    """
    try:
        conn = sqlite3.connect("customer_data.db")
        cursor = conn.cursor()

        print("Connecting to the database to retrieve user transactions...")
        print(f"User Identifier: {user_identifier}")
        print("Executing query to fetch transactions...")
        
        # Query to get all transactions for the specified user
        query = """
        SELECT ut.ID, ut.UserID, ut.Type, ut.Amount, ut.Date, ut.Counterparty, ut.AccountNumber, ut.Description 
        FROM user_transactions ut
        JOIN user u ON ut.UserID = u.UserID
        WHERE ut.UserID = ? OR u.Name LIKE ?
        ORDER BY ut.Date
        """
        
        # Add wildcards for partial name matching
        name_pattern = f"%{user_identifier}%"
        cursor.execute(query, (user_identifier, name_pattern))
        transactions = cursor.fetchall()
        
        # Convert the results to a list of dictionaries
        result = []
        for transaction in transactions:
            result.append({
                'ID': transaction[0],
                'UserID': transaction[1],
                'Type': transaction[2],
                'Amount': transaction[3],
                'Date': transaction[4],
                'Counterparty': transaction[5],
                'AccountNumber': transaction[6],
                'Description': transaction[7]
            })
        
        return result
        
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        return []
    finally:
        if conn:
            conn.close()


def get_basic_account_information(user_identifier: str) -> List[Dict[str, Any]]:
    """
    Retrieve basic account information for a specific user by ID or partial name.
    
    Args:
        user_identifier (str): The ID or partial name of the user to retrieve information for
        
    Returns:
        List[Dict[str, Any]]: List of dictionaries containing user basic information
        Each dictionary contains: UserID, Name, Address, AccountBalance, and AccountTypes
    """
    try:
        conn = sqlite3.connect("customer_data.db")
        cursor = conn.cursor()
        
        # Query to get basic account information for the specified user
        query = """
        SELECT UserID, Name, Address, AccountBalance, AccountTypes 
        FROM user
        WHERE UserID = ? OR Name LIKE ?
        """
        
        # Add wildcards for partial name matching
        name_pattern = f"%{user_identifier}%"
        cursor.execute(query, (user_identifier, name_pattern))
        users = cursor.fetchall()
        
        # Convert the results to a list of dictionaries
        result = []
        for user in users:
            result.append({
                'UserID': user[0],
                'Name': user[1],
                'Address': user[2],
                'AccountBalance': user[3],
                'AccountTypes': user[4]
            })
        
        return result
        
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        return []
    finally:
        if conn:
            conn.close()
    
    
# def online_web_search(search_query: str):
#     """
#     Perform an online web search.
    
#     Parameters:
#         search_query (str): The search query.
    
#     Returns:
#         dict: The search results in JSON format.
#     """
#     url = "https://api.tavily.com/search"
#     headers = {"Content-Type": "application/json"}
#     data = {"api_key": "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", "query": search_query, "max_results": 10}
    
#     response = requests.post(url, json=data, headers=headers)
#     return response.json()

def online_web_search_openai_tool(search_query: str):
    """
    Perform an online web search.
    
    Parameters:
        search_query (str): The search query.
    
    Returns:
        dict: The search results in JSON format.
    """
    llm = ChatOpenAI(model="gpt-4o-mini")

    tool = {"type": "web_search_preview"}
    llm_with_tools = llm.bind_tools([tool])

    response = llm_with_tools.invoke(search_query)
    return response 

import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX
import warnings
import io
import base64
import time

def forecast_monthly_deposite_or_expense(json_data: dict, chart_type: str = "deposit", forecast_months: int = 6) -> dict:
    """
    Generates a monthly deposite/expense forecast plot and a table of forecasted values
    for the specified number of months from a given Python Dict financial transaction data.

    Args:
        json_data (dict): A dictionary containing transaction data in the format:
                          {"transactions": [{"ID": ..., "Type": "CR/DR", "Amount": ..., "Date": ..., ...}]}
        chart_type (str): Type of chart to generate - "deposit" or "expenses"
        forecast_months (int): Number of months to forecast (default: 6)

    Returns:
        dict: Dictionary containing "image_path" and "forecast_table" keys
    """
    warnings.filterwarnings("ignore")

    # Get the absolute path to the static directory
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    output_dir = os.path.join(base_dir, "static", "charts")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Convert to DataFrame
    df = pd.DataFrame(json_data['transactions'])

    # Filter transactions based on chart type
    if chart_type.lower() == "deposit":
        filtered_df = df[df['Type'] == 'CR'].copy()
        title_prefix = "Monthly Deposite"
    else:  # expenses
        filtered_df = df[df['Type'] == 'DR'].copy()
        title_prefix = "Monthly Expenses"

    # Check if we have any data after filtering
    if filtered_df.empty:
        return {
            "error": f"No {chart_type.lower()} transactions found in the provided data. Cannot generate forecast."
        }

    # Convert 'Date' to datetime objects
    filtered_df['Date'] = pd.to_datetime(filtered_df['Date'])

    # Set 'Date' as index
    filtered_df.set_index('Date', inplace=True)

    # Resample to monthly frequency and sum the 'Amount'
    monthly_data = filtered_df['Amount'].resample('MS').sum()

    # Check if we have enough data points for forecasting
    if len(monthly_data) < 2:
        return {
            "error": f"Insufficient data for forecasting. Need at least 2 months of {chart_type.lower()} data, but only found {len(monthly_data)} month(s)."
        }

    # Convert to DataFrame for easier plotting and manipulation
    monthly_df = monthly_data.reset_index()
    monthly_df.rename(columns={'Date': 'ds', 'Amount': 'y'}, inplace=True)
    monthly_df['ds'] = monthly_df['ds'].dt.to_period('M')
    monthly_df = monthly_df.set_index('ds')

    # Define SARIMAX parameters (simplified for small datasets)
    order = (1, 0, 0)
    seasonal_order = (0, 0, 0, 0)

    try:
        # Fit SARIMAX Model
        model = SARIMAX(monthly_df['y'], order=order, seasonal_order=seasonal_order,
                        enforce_stationarity=False, enforce_invertibility=False)
        model_fit = model.fit(disp=False)

        # Forecast for the specified number of months
        forecast_result = model_fit.get_forecast(steps=forecast_months)
        forecast_mean = forecast_result.predicted_mean
        forecast_conf_int = forecast_result.conf_int()
    except Exception as e:
        return {
            "error": f"Failed to fit forecasting model: {str(e)}. This might be due to insufficient or irregular data patterns."
        }

    # Handle scalar values by converting to arrays
    if hasattr(forecast_mean, 'values'):
        forecast_mean_values = forecast_mean.values
    else:
        # If forecast_mean is a scalar, create an array with the same value
        forecast_mean_values = np.full(forecast_months, forecast_mean)
    
    if hasattr(forecast_conf_int['lower y'], 'values'):
        lower_values = forecast_conf_int['lower y'].values
    else:
        # If lower bound is a scalar, create an array
        lower_values = np.full(forecast_months, forecast_conf_int['lower y'])
    
    if hasattr(forecast_conf_int['upper y'], 'values'):
        upper_values = forecast_conf_int['upper y'].values
    else:
        # If upper bound is a scalar, create an array
        upper_values = np.full(forecast_months, forecast_conf_int['upper y'])

    # Create dates for the forecast period
    last_date_period = monthly_df.index.max()
    forecast_period_index = pd.period_range(start=last_date_period + 1, periods=forecast_months, freq='M')

    # Prepare forecast data for plotting
    forecast_df = pd.DataFrame({
        'yhat': forecast_mean_values,
        'yhat_lower': lower_values,
        'yhat_upper': upper_values
    }, index=forecast_period_index)

    # --- Monthly Forecast Plot ---
    plt.figure(figsize=(14, 7))
    
    # Plot historical data
    plt.plot(monthly_df.index.to_timestamp(), monthly_df['y'], 
             label=f'Historical {title_prefix}', marker='o', color='blue')
    
    # Plot forecast data
    plt.plot(forecast_df.index.to_timestamp(), forecast_df['yhat'], 
             label=f'Forecasted {title_prefix} ({forecast_months} months)', 
             color='red', linestyle='--', marker='x')
    
    # Add confidence interval
    plt.fill_between(forecast_df.index.to_timestamp(), 
                     forecast_df['yhat_lower'], forecast_df['yhat_upper'], 
                     color='pink', alpha=0.3, 
                     label=f'95% Confidence Interval ({forecast_months} months)')
    
    # Add vertical line to separate historical and forecast data
    last_historical_date = monthly_df.index.to_timestamp()[-1]
    plt.axvline(x=last_historical_date, color='gray', linestyle='--', alpha=0.5,
                label='Forecast Start')
    
    plt.title(f'{title_prefix} Forecast (SARIMAX Model) - Next {forecast_months} Months', fontsize=18)
    plt.xlabel('Date', fontsize=14)
    plt.ylabel('Total Amount', fontsize=14)
    plt.legend(fontsize=12, loc='upper left')
    plt.grid(True, linestyle=':', alpha=0.7)
    plt.xticks(rotation=45)
    plt.tight_layout()

    # Generate a unique filename with timestamp to prevent caching
    timestamp = int(time.time())
    image_filename = f'monthly_forecast_{timestamp}.png'
    image_path = os.path.join(output_dir, image_filename)
    
    # Save plot to file
    plt.savefig(image_path, format='png', bbox_inches='tight')
    plt.close()

    # --- Forecasted Values Table ---
    forecast_output = forecast_df[['yhat', 'yhat_lower', 'yhat_upper']].copy()
    forecast_output.index = forecast_output.index.strftime('%Y-%m')
    forecast_table = forecast_output.to_markdown(numalign="left", stralign="left")

    # Get localhost IP address and construct full URL
    localhost_ip = get_localhost_ip()
    port = "8090"  # Default port, you can make this configurable if needed
    full_image_url = f"http://{localhost_ip}:{port}/static/charts/{image_filename}"
    
    return {
        "image_path": full_image_url,
        "forecast_table": forecast_table
    }




def sync_fetch_agent_cards():
    PUBLIC_AGENT_CARD_PATH = '/.well-known/agent.json'
    base_url = 'http://127.0.0.1:9999'
    max_retries = 1
    timeout = httpx.Timeout(30.0, connect=10.0)

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    agents_name = []
    for attempt in range(max_retries):
        try:
            with httpx.Client(timeout=timeout) as httpx_client:
                resolver = A2ACardResolver(
                    httpx_client=httpx_client,
                    base_url=base_url,
                )

                try:
                    # Make a synchronous request
                    response = httpx_client.get(f"{base_url}{PUBLIC_AGENT_CARD_PATH}")
                    if response.status_code == 200:
                        _public_card = AgentCard.model_validate_json(response.text)
                        logger.info(
                            _public_card.model_dump_json(indent=2, exclude_none=True)
                        )
                        
                        # Add agent name and description to the list
                        if _public_card.name and _public_card.description:
                            agents_name.append(f"{_public_card.name} - {_public_card.description}")
                    else:
                        logger.error(f"Failed to fetch agent card. Status code: {response.status_code}")
                    
                except Exception as e:
                    logger.error(
                        f'Critical error fetching public agent card (Attempt {attempt + 1}/{max_retries}): {e}', exc_info=True
                    )
                    if attempt == max_retries - 1:
                        agents_name = []
                    continue

        except Exception as e:
            logger.error(f"Error in customer_info_agent (Attempt {attempt + 1}/{max_retries}): {str(e)}", exc_info=True)
            if attempt == max_retries - 1:
                agents_name = []
            continue

    # If no agents were found, use default
    if not agents_name:
        agents_name = []

    return agents_name


# Mid-level agent combining tools
customer_information_agent = LlmAgent(
    name="CustomerInformationAgent",
    model=LiteLlm(model="openai/gpt-4.1"),
    description="""
        **Tools**
            - 'get_user_transactions' - Get the transactions of the user.
            - 'get_basic_account_information' - Get the basic account information of the user.

        **Objective**
            - You are a Customer Information Agent and your goal is to assist users in finding information about their transactions.
            - Clearly understand the 'User Query' and use the appropriate tool to get the required information.

        **Instructions**
            - If you want to get the transactions of the user, pass the 'UserID' to the tool 'get_user_transactions' and get the transactions of the user. 
            - If you want to get the basic account information of the user, pass the 'UserID' to the tool 'get_basic_account_information' and get the basic account information of the user.
            - If you can't find the required information, using the available tools, mention it in final answer. 
            - If you can't find the required information, don't answer those by yourself, mention it in final answer.

        **Expected Output**
            - When you get the transactions of the user, return the Python Dict data of the transactions of the user. (Data format should be - {"transactions": [{"ID": ..., "Type": "CR/DR", "Amount": ..., "Date": ..., ...}]})
            - When you get the basic account information of the user, return the User's details in String format.
    """,
    tools=[get_user_transactions, get_basic_account_information]
)

deposite_or_expense_prediction_agent = LlmAgent(
    name="DepositeOrExpensePredictionAgent",
    model=LiteLlm(model="openai/gpt-4.1"),
    description="""
        **Tools**
            - 'forecast_monthly_deposite_or_expense' - Forecast the monthly deposite or expense for the requested months.

        **Objective**
            - You are a deposite or expense Prediction Agent and your goal is to assist users in forecasting their monthly deposite or expense.
            - According to user's previous transactions, forecast the monthly deposite or expense for the requested months.

        **Instructions**
            - If you want to forecast the monthly deposite or expense for the requested months, Make sure to identify below given information from the user query and pass it to the tool 'forecast_monthly_deposite_or_expense' to get the forecasted deposite or expense.,
                - Python Dict data - Identify the fully complete Python Dict data of the transactions. (Data format should be - {"transactions": [{"ID": ..., "Type": "CR/DR", "Amount": ..., "Date": ..., ...}]})
                - Chart Type - Identify the type of chart to generate - "deposit" or "expenses" from the user query. If you can't find it, use "deposit" as default.
                - Forcast Months - Identify the number of months to forecast (default: 6) from the user query.
            - If you can't find the required information, using the available tools, mention it in final answer. 
            - If you can't find the required information, don't answer those by yourself, mention it in final answer.

        **Expected Output**
            - The tool returns a dictionary with "image_path" and "forecast_table" keys.
            - Chart image of forcasted deposite or expense for the next requested months period with 100% width - Use the "image_path" from the returned dictionary (Make sure to use absolute attribute in image element same as given. Eg: src and width) = <img src="{image_path}" width="900" alt="Monthly Income Forecast">
            - Table view of forcasted deposite or expense for the next requested months period - Use the "forecast_table" from the returned dictionary.
    """,
    tools=[forecast_monthly_deposite_or_expense]
)


from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StdioServerParameters
# High-level agent delegating research

TARGET_FOLDER_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mcp_salesforce_api.py")

mcp_saleforce_server = MCPToolset(
            connection_params=StdioServerParameters(
                command='python',
                args=[
                    os.path.abspath(TARGET_FOLDER_PATH),
                ],
            ),
        )


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# Global variable to store MCP tools
mcp_tools_list = []

# Get MCP tools
async def list_mcp_tools():
    global mcp_tools_list
    try:
        params = StdioServerParameters(
            command='python',
            args=[
                os.path.abspath(TARGET_FOLDER_PATH),
            ],
        )

        mcp_toolset = MCPToolset(connection_params=params)
        tools = await mcp_toolset.get_tools()
        
        # Store all tools in a single variable
        all_tools = []
        
        # Print tool details
        print("\n=== MCP Tools Details ===")
        print(f"Total tools available: {len(tools)}")
        for i, tool in enumerate(tools, 1):
            tool_info = {
                'name': tool.name,
                'description': tool.description,
                'parameters': []
            }
            
            if hasattr(tool, 'parameters'):
                for param in tool.parameters:
                    tool_info['parameters'].append({
                        'name': param.name,
                        'description': param.description
                    })
            
            all_tools.append(tool_info)
            
            # Print individual tool details
            print(f"\nTool {i}:")
            print(f"Name: {tool.name}")
            print(f"Description: {tool.description}")
            if hasattr(tool, 'parameters'):
                print("Parameters:")
                for param in tool.parameters:
                    print(f"  - {param.name}: {param.description}")
        
        print("\n=======================")
        print("\nAll Tools Summary:")
        print(all_tools)
        
        # Store tools in global variable
        mcp_tools_list = all_tools
        
        # Clean up resources
        if hasattr(mcp_toolset, 'close'):
            await mcp_toolset.close()
        return all_tools
    except Exception as e:
        logger.error(f"Error in list_mcp_tools: {str(e)}")
        raise

def sync_list_mcp_tools():
    """
    Synchronous wrapper for list_mcp_tools that handles the async operation.
    Returns the list of MCP tools.
    """
    try:
        # Get or create event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        # Check if we're already in an event loop
        if loop.is_running():
            # Create a new event loop for this operation
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                return new_loop.run_until_complete(list_mcp_tools())
            finally:
                new_loop.close()
        else:
            # Use the existing loop
            return loop.run_until_complete(list_mcp_tools())
    except Exception as e:
        logger.error(f"Error in sync_list_mcp_tools: {str(e)}")
        raise

# Use the current event loop
import asyncio
try:
    loop = asyncio.get_running_loop()
    # Create a task but don't wait for it
    loop.create_task(list_mcp_tools())
except RuntimeError:
    # If no loop is running, create a new one
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.create_task(list_mcp_tools())

import asyncio
import nest_asyncio

# Apply nest_asyncio to allow nested event loops
nest_asyncio.apply()

def root_agent_instruction() -> str:
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    # Get agent names from fetch_agent_cards
    agents_name = []
    try:
        # Call the synchronous function directly
        agents_name = sync_fetch_agent_cards()
    except Exception as e:
        logging.error(f"Error fetching agent cards: {str(e)}")
        # Keep default agent name if there's an error
        agents_name = []

    agents_name_str = "\n".join([f"{i+3}. {name}" for i, name in enumerate(agents_name)])

    # Ensure MCP tools are loaded
    global mcp_tools_list
    if not mcp_tools_list:
        try:
            # Create a new event loop for this operation
            async def get_mcp_tools():
                params = StdioServerParameters(
                    command='python',
                    args=[
                        os.path.abspath(TARGET_FOLDER_PATH),
                    ],
                )
                mcp_toolset = MCPToolset(connection_params=params)
                try:
                    tools = await mcp_toolset.get_tools()
                    all_tools = []
                    for tool in tools:
                        tool_info = {
                            'name': tool.name,
                            'description': tool.description,
                            'parameters': []
                        }
                        if hasattr(tool, 'parameters'):
                            for param in tool.parameters:
                                tool_info['parameters'].append({
                                    'name': param.name,
                                    'description': param.description
                                })
                        all_tools.append(tool_info)
                    return all_tools
                finally:
                    if hasattr(mcp_toolset, 'close'):
                        await mcp_toolset.close()

            # Get the current event loop
            loop = asyncio.get_event_loop()
            # Run the async function in the current loop
            mcp_tools_list = loop.run_until_complete(get_mcp_tools())
                
        except Exception as e:
            logger.error(f"Error loading MCP tools: {str(e)}")
            mcp_tools_list = []

    # Format MCP tools list into a string
    mcp_tools_str = "\n".join([
        f"'{tool['name']}' - {tool['description']}"
        for tool in mcp_tools_list
    ]) if mcp_tools_list else "No MCP tools available"

    final_prompt = f"""
        
        **Tools Available to Use** 
            - 'rag_inquiry_handler_tool' - Make sure only search and gather the required information about the our company 'JPMorgan Chase & Co'.
            - 'online_web_search_openai_tool' -  Make sure only search and gather the required information about the user given company, other than our company 'JPMorgan Chase & Co'.
            - 'code_interpreter_tool' - Execute the provided Python code and return the output.
            - {mcp_tools_str}

        **Other Agents Available to Use**
            1. 'customer_information_agent' - Get the information about the user's interactions and transactions.
            2. 'deposite_or_expense_prediction_agent' - Forecast the monthly deposite / expenses for the next requested months period and show the chart image and table view of forecasted deposite or expense for the next requested months period.
            {agents_name_str}

        **Objective**
            - You are a Researcher Agent In Financial Company and your goal is to assist users in finding information on the web, in documents, and through calculations.
            - Clearly understand the 'User Query' and use the appropriate tool to get the required information.
            - Generate the answer based on the information gathered.    
            
        **Instructions**
            - If you want to search and gather the required information about the our company 'JPMorgan Chase & Co', use the tool 'rag_inquiry_handler_tool'.
            - If you want to search and gather the required information about the user given company, other than our company 'JPMorgan Chase & Co', use the tool 'online_web_search'.
            - If you want to execute the provided Python code and return the output, use the tool 'code_interpreter_tool'.
            - If you want to get the specific information about the user's transactions, use the tool 'customer_information_agent'.
            - If you want to forecast the monthly deposite / expenses for the next requested months period, make sure pass transacion Python Dict to the tool 'deposite_or_expense_prediction_agent'. and show the chart image and table view of forecasted deposite or expense for the next requested months period.
            - When enters the 'UserID' or 'Name' of the user, don' ask for the 'UserID' or 'Name' again. Only pass given 'UserID' or 'Name' to the tool 'customer_information_agent' to get the information about the user.
            - If you cannot find user details from the 'customer_information_agent' ask the user to provide the 'UserID' or 'Name' of the user to get the information or correct the 'UserID' or 'Name' of the user to get the information.
            - If you want to perform any calculations, don't do it manually, generate the python code and use the tool 'code_interpreter_tool' to execute the code and get the output.
            - Think step by step about the 'User Query' and use the appropriate tool to get the required information.
            - If you can't find the required information, using the available tools, mention it in final answer. 
            - If you can't find the required information, don't answer those by yourself, mention it in final answer.
            - Finally, provide the answer to the 'User Query' based on the information gathered.
            - When show the answer, make sure to use human readable format. (Don't show the answer in Python Dict format) and make sure to don't show summary of the answer, just show the answer as it is, if user doesn't ask for summary.
            - Make sure don't fetch other users information, only fetch the information of the requested user.
            - Very Important thing is each and every time make sure to give the answer to the user's query based on the gathered information.
    """
    logger.info("==============================================================")
    logger.info("==============================================================")
    logger.info(final_prompt)
    logger.info("==============================================================")
    logger.info("==============================================================")

    return final_prompt

# High-level agent delegating research
root_agent = LlmAgent(
    name="ManagerAgent",
    model=LiteLlm(model="openai/gpt-4.1"),
    instruction=root_agent_instruction(),
    tools=[agent_tool.AgentTool(agent=customer_information_agent), agent_tool.AgentTool(agent=deposite_or_expense_prediction_agent), rag_inquiry_handler_tool, online_web_search_openai_tool, code_interpreter_tool, get_user_interactions_A2A_server, mcp_saleforce_server]
)