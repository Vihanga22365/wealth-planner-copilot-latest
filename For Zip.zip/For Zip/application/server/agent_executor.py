# =============================================================================
# agents/tell_time_agent/agent_executor.py
# =============================================================================
# Purpose:
# This file defines the "executor" that acts as a bridge between the A2A server
# and the underlying TellTime agent. It listens to tasks and dispatches them to
# the agent, then sends back task updates and results through the event queue.
# =============================================================================

# -----------------------------------------------------------------------------
# Imports
# -----------------------------------------------------------------------------

from .agent import CustomerInfoAgent  # Imports the TellTimeAgent class from the same directory

# Importing base classes from the A2A SDK to define agent behavior
from a2a.server.agent_execution import AgentExecutor  # Base class for defining agent task executor logic
from a2a.server.agent_execution import RequestContext  # Holds information about the incoming user query and context

# EventQueue is used to push updates back to the A2A server (e.g., task status, results)
from a2a.server.events.event_queue import EventQueue

# Importing event and status types for responding to client
from a2a.types import (
    TaskArtifactUpdateEvent,  # Event for sending result artifacts back to the client
    TaskStatusUpdateEvent,   # Event for sending status updates (e.g., working, completed)
    TaskStatus,              # Object that holds the current status of the task
    TaskState,               # Enum that defines states: working, completed, input_required, etc.
)

# Utility functions to create standardized message and artifact formats
from a2a.utils import (
    new_agent_text_message,  # Creates a message object from agent to client
    new_task,                # Creates a new task object from the initial message
    new_text_artifact        # Creates a textual result artifact
)

# -----------------------------------------------------------------------------
# CustomerInfoAgentExecutor: Connects the agent logic to A2A server infrastructure
# -----------------------------------------------------------------------------

class CustomerInfoAgentExecutor(AgentExecutor):  # Define a new executor by extending A2A's AgentExecutor
    """
    This class connects the TellTimeAgent to the A2A server runtime. It implements
    the `execute` function to run tasks and push updates to the event queue.
    """

    def __init__(self):
        self.agent = CustomerInfoAgent()


    async def execute(
        self,
        context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        query = context.get_user_input()  # Extracts the actual text of the user's message
        task = context.current_task      # Gets the task object if it already exists
        result = await self.agent.invoke(query)
        event_queue.enqueue_event(new_agent_text_message(result))

    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        raise Exception('cancel not supported')