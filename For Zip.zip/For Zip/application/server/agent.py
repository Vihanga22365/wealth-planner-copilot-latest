# =============================================================================
# agents/tell_time_agent/agent.py
# =============================================================================
# Purpose:
# This file defines the TellTimeAgent.
# - It uses LangChain ReAct agent with Gemini (via langchain-google-genai)
# - It supports streaming responses
# - It defines a simple tool: get_time_now()
# - It handles structured responses with support for multi-turn logic
# =============================================================================

# -----------------------------------------------------------------------------
# Imports
# -----------------------------------------------------------------------------

from datetime import datetime                      # To get the current system time
from typing import Any, Literal, AsyncIterable     # Type annotations for cleaner, safer code
import logging                                     # To optionally print internal debug/info messages

from pydantic import BaseModel                     # Used to define response validation schemas
from .chatbot import ChatbotClient

# -----------------------------------------------------------------------------
# Logging setup
# -----------------------------------------------------------------------------
logger = logging.getLogger(__name__)               # Setup logging for debugging (not actively used)

class CustomerInfoAgent:
    """Customer Information Agent."""

    def __init__(self):
        # Initialize the client with hardcoded credentials
        self.client = ChatbotClient(
            client_id="3MVG9dAEux2v1sLuTVYi6GqAW8XIwyNKuoxdphM7LDScFnoBasYpaUWRTiRHMNe9Y8G7zoxSkm6gYW4LZpTfY",
            client_secret="FAFB7DECE0B756EF9747D073FE70DFC5D10DB8FD50D06253586F6269F6822DB7",
            instance_url="https://orgfarm-4d2118a60b-dev-ed.develop.my.salesforce.com"
        )
        self.client.start_session()

    async def invoke(self, message: str) -> str:
        """Invoke the agent with a message and return the response."""
        try:
            response = self.client.send_message(message)
            return str(response)
        except Exception as e:
            logger.error(f"Error in invoke: {str(e)}")
            return f"Error: {str(e)}"

    def __del__(self):
        """Cleanup: end the session when the agent is destroyed."""
        if hasattr(self, 'client'):
            self.client.end_session()