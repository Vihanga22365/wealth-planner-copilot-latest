import requests
import time
import uuid
from datetime import datetime, timedelta

class ChatbotClient:
    def __init__(self, client_id, client_secret, instance_url):
        self.client_id = client_id
        self.client_secret = client_secret
        self.instance_url = instance_url
        self.access_token = None
        self.token_expiry = None
        self.session_id = None
        self.sequence_id = 0
        self.agent_id = "0XxgL000000Lhl7SAC"  # Your agent ID
        
    def get_access_token(self):
        """Generate a new access token"""
        url = f"{self.instance_url}/services/oauth2/token"
        payload = {
            'grant_type': 'client_credentials',
            'client_id': self.client_id,
            'client_secret': self.client_secret
        }
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        response = requests.post(url, data=payload, headers=headers)
        if response.status_code == 200:
            data = response.json()
            self.access_token = data['access_token']
            # Set token expiry to 25 minutes (giving 5-minute buffer)
            self.token_expiry = datetime.now() + timedelta(minutes=25)
            return self.access_token
        else:
            raise Exception(f"Failed to get access token: {response.text}")

    def ensure_valid_token(self):
        """Ensure the access token is valid, refresh if needed"""
        if not self.access_token or not self.token_expiry or datetime.now() >= self.token_expiry:
            self.get_access_token()

    def start_session(self):
        """Start a new chat session"""
        self.ensure_valid_token()
        
        url = f"https://api.salesforce.com/einstein/ai-agent/v1/agents/{self.agent_id}/sessions"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.access_token}'
        }
        
        payload = {
            "externalSessionKey": str(uuid.uuid4()),
            "instanceConfig": {
                "endpoint": self.instance_url
            },
            "tz": "America/Los_Angeles",
            "variables": [
                {
                    "name": "$Context.EndUserLanguage",
                    "type": "Text",
                    "value": "en_US"
                }
            ],
            "featureSupport": "Streaming",
            "streamingCapabilities": {
                "chunkTypes": ["Text"]
            },
            "bypassUser": True
        }
        
        print(f"Starting new session with agent ID: {self.agent_id}")
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code == 200:
            data = response.json()
            self.session_id = data['sessionId']
            print(f"Session started successfully: {self.session_id}")
            return self.session_id
        else:
            print(f"Failed to start session. Status: {response.status_code}, Response: {response.text}")
            raise Exception(f"Failed to start session: {response.text}")

    def check_session_validity(self):
        """Check if the current session is still valid"""
        if not self.session_id:
            return False
            
        self.ensure_valid_token()
        
        url = f"https://api.salesforce.com/einstein/ai-agent/v1/sessions/{self.session_id}"
        headers = {
            'Authorization': f'Bearer {self.access_token}'
        }
        
        response = requests.get(url, headers=headers)
        return response.status_code == 200

    def ensure_valid_session(self):
        """Ensure we have a valid session, create new one if needed"""
        if not self.session_id or not self.check_session_validity():
            print("Session invalid or expired, starting new session...")
            self.session_id = None
            self.sequence_id = 0
            self.start_session()

    def send_message(self, message_text):
        """Send a message to the chatbot"""
        # Ensure we have a valid session before sending
        self.ensure_valid_session()
            
        self.ensure_valid_token()
        self.sequence_id += 1
        
        url = f"https://api.salesforce.com/einstein/ai-agent/v1/sessions/{self.session_id}/messages"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.access_token}'
        }
        
        payload = {
            "message": {
                "sequenceId": self.sequence_id,
                "type": "Text",
                "text": message_text
            },
            "variables": []
        }

        print("======================")
        print(f"Session ID: {self.session_id} | Sequence ID: {self.sequence_id}")
        print(f"Sending message: {message_text}")
        print("======================")
        
        response = requests.post(url, json=payload, headers=headers)
        
        # Handle 401 Unauthorized - refresh token and retry
        if response.status_code == 401:
            self.get_access_token()
            headers['Authorization'] = f'Bearer {self.access_token}'
            response = requests.post(url, json=payload, headers=headers)
        
        # Handle 404 Not Found - session expired, start new session and retry
        if response.status_code == 404:
            print("Session not found, starting new session...")
            self.session_id = None
            self.sequence_id = 0
            self.start_session()
            # Retry with new session
            return self.send_message(message_text)
        
        if response.status_code == 200:
            response_data = response.json()
            # Extract just the message content from the first message in the response
            if response_data.get('messages') and len(response_data['messages']) > 0:
                return response_data['messages'][0].get('message', '')
            return ''
        else:
            print(f"Error response: Status {response.status_code}, Body: {response.text}")
            raise Exception(f"Failed to send message: {response.text}")

    def end_session(self):
        """End the current chat session"""
        if not self.session_id:
            return
            
        self.ensure_valid_token()
        
        url = f"https://api.salesforce.com/einstein/ai-agent/v1/sessions/{self.session_id}"
        headers = {
            'x-session-end-reason': 'UserRequest',
            'Authorization': f'Bearer {self.access_token}'
        }
        
        response = requests.delete(url, headers=headers)
        if response.status_code == 401:
            # Unauthorized, try to refresh token and retry once
            self.get_access_token()
            headers['Authorization'] = f'Bearer {self.access_token}'
            response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            self.session_id = None
            return True
        else:
            raise Exception(f"Failed to end session: {response.text}") 