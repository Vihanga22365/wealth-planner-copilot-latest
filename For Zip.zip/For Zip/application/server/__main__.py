import uvicorn

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
)
from server.agent_executor import CustomerInfoAgentExecutor  # Fixed import path


if __name__ == '__main__':
    skill = AgentSkill(
        id='customer_info_agent',
        name='Get customer information Agent',
        description="Fetch specific customer interaction information from the Salesforce database (Agentforce). If user ask customer interaction information, Pass the user full message to the agent through 'get_user_interactions_A2A_server' tool ",
        tags=['customer_info'],
        examples=['I want to know about the customer whose name is John Doe', 'What is the customer information of John Doe'],
    )


    # This will be the public-facing agent card
    public_agent_card = AgentCard(
        name='Get customer information Agent',
        description="Fetch specific customer interaction information from the Salesforce database (Agentforce). If user ask customer interaction information, Pass the user full message to the agent through 'get_user_interactions_A2A_server' tool",
        url='http://127.0.0.1:9999/',
        version='1.0.0',
        defaultInputModes=['text'],
        defaultOutputModes=['text'],
        capabilities=AgentCapabilities(streaming=True),
        skills=[skill],  # Only the basic skill for the public card
        supportsAuthenticatedExtendedCard=True,
    )

    request_handler = DefaultRequestHandler(
        agent_executor=CustomerInfoAgentExecutor(),
        task_store=InMemoryTaskStore(),
    )

    server = A2AStarletteApplication(
        agent_card=public_agent_card,
        http_handler=request_handler,
    )

    uvicorn.run(server.build(), host='0.0.0.0', port=9999)