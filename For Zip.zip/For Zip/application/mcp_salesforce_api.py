import requests
from typing import Dict, Any, Optional, List
from datetime import datetime
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Salesforce")

# Global configuration
BASE_URL = "https://orgfarm-4d2118a60b-dev-ed.develop.my.salesforce.com"
CLIENT_ID = "3MVG9dAEux2v1sLuTVYi6GqAW8XIwyNKuoxdphM7LDScFnoBasYpaUWRTiRHMNe9Y8G7zoxSkm6gYW4LZpTfY"
CLIENT_SECRET = "FAFB7DECE0B756EF9747D073FE70DFC5D10DB8FD50D06253586F6269F6822DB7"
access_token = None

def get_access_token() -> Dict[str, Any]:
    """
    Get Salesforce access token using client credentials flow
    """
    global access_token
    url = f"{BASE_URL}/services/oauth2/token"
    
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    data = {
        'grant_type': 'client_credentials',
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET
    }
    
    response = requests.post(url, headers=headers, data=data)
    response.raise_for_status()
    
    access_token = response.json()['access_token']
    return response.json()

def format_ticket_data(ticket: Dict[str, Any]) -> str:
    """
    Format a single ticket's data into a readable string
    """
    return f"""Ticket ID: {ticket['Ticket_ID__c']}
User Name: {ticket['User_Name__c']}
Open Date: {ticket['Open_Date__c']}
Issue: {ticket['Issue__c']}
Status: {ticket['Status__c']}
"""

def format_tickets_response(response: Dict[str, Any]) -> str:
    """
    Format the entire tickets response into a readable string
    """
    if not response.get('records'):
        return "No tickets found."
    
    formatted_tickets = []
    for ticket in response['records']:
        formatted_tickets.append(format_ticket_data(ticket))
    
    return "\n".join(formatted_tickets)

@mcp.tool()
def salesforce_customer_tickets_mcp_server(user_identifier: str) -> str:
    """
    Search support tickets by either user ID or user name and return formatted response. The function will search for exact match on User_ID__c and partial match on User_Name__c.
    """
    global access_token
    if not access_token:
        get_access_token()
        
    url = f"{BASE_URL}/services/data/v62.0/query"
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {access_token}'
    }
    
    query = f"SELECT Ticket_ID__c, User_Name__c, Open_Date__c, Issue__c, Status__c FROM Support_Ticket__c WHERE User_ID__c='{user_identifier}' OR User_Name__c LIKE '%{user_identifier}%'"
    params = {'q': query}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        if response.status_code == 401:
            # Refresh token and retry once
            get_access_token()
            headers['Authorization'] = f'Bearer {access_token}'
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
        else:
            raise
    
    return format_tickets_response(response.json())

if __name__ == "__main__":
    mcp.run(transport="stdio")