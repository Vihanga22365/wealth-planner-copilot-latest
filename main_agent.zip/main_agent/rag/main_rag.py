import os
from langchain_community.document_loaders import DirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from dotenv import load_dotenv
from langchain_community.vectorstores import FAISS


from langchain_google_genai import GoogleGenerativeAIEmbeddings

load_dotenv(dotenv_path='../.env')

os.environ['GOOGLE_API_KEY'] = os.getenv('GOOGLE_API_KEY')

document_path = "./documents/"
loader = DirectoryLoader(document_path, show_progress=True)
documents = loader.load()

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=10000,
    chunk_overlap=200,
)
split_documents = text_splitter.split_documents(documents)

# Create embeddings and store in FAISS
embeddings = GoogleGenerativeAIEmbeddings(model="models/gemini-embedding-exp-03-07")
db = FAISS.from_documents(split_documents, embeddings)

# Save the FAISS database locally
db.save_local("faiss_db")